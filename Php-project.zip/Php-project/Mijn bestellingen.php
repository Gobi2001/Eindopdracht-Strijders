<?php
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mijn bestellingen</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>


<body>

<span class="badge badge-primary" style="margin-left: 500px; margin-top: 20px;"><h2>MIJN BESTELLINGEN</h2></span>

<div class="container" style=" margin-top: 20px;background-color: darkgray; width: auto; height: auto">
    <div class="card mb-3" style="max-width: 540px; height: 200px">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="..." class="card-img" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body" style="width: 540px;">
                    <h5 class="card-title">Naam Fiets</h5>
                    <p class="card-text">Prijs</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <button type="button" class="btn btn-primary" style="margin-top: 20px; margin-left: 200px;">Informatie</button>
                </div>
            </div>
        </div>
    </div>
    <div class="card mb-3" style="max-width: 540px; height: 200px; float: right; margin-top: -215px">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="..." class="card-img" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body" style="width: 540px;">
                    <h5 class="card-title">Naam Fiets</h5>
                    <p class="card-text">Prijs</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <button type="button" class="btn btn-primary" style="margin-top: 20px; margin-left: 200px;">Informatie</button>
                </div>
            </div>
        </div>
    </div>
    <div class="card mb-3" style="max-width: 540px; height: 200px">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="..." class="card-img" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body" style="width: 540px;">
                    <h5 class="card-title">Naam Fiets</h5>
                    <p class="card-text">Prijs</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <button type="button" class="btn btn-primary" style="margin-top: 20px; margin-left: 200px;">Informatie</button>
                </div>
            </div>
        </div>
    </div>
    <div class="card mb-3" style="max-width: 540px; height: 200px; float: right; margin-top: -215px">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="..." class="card-img" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body" style="width: 540px;">
                    <h5 class="card-title">Naam Fiets</h5>
                    <p class="card-text">Prijs</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <button type="button" class="btn btn-primary" style="margin-top: 20px; margin-left: 200px;">Informatie</button>
                </div>
            </div>
        </div>
    </div>
    <div class="card mb-3" style="max-width: 540px; height: 200px">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="..." class="card-img" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body" style="width: 540px;">
                    <h5 class="card-title">Naam Fiets</h5>
                    <p class="card-text">Prijs</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <button type="button" class="btn btn-primary" style="margin-top: 20px; margin-left: 200px;">Informatie</button>
                </div>
            </div>
        </div>
    </div>
    <div class="card mb-3" style="max-width: 540px; height: 200px; float: right; margin-top: -215px">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="..." class="card-img" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body" style="width: 540px;">
                    <h5 class="card-title">Naam Fiets</h5>
                    <p class="card-text"> Prijs</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <button type="button" class="btn btn-primary" style="margin-top: 20px; margin-left: 200px;">Informatie</button>
                </div>
            </div>
        </div>
    </div>
    <div class="card mb-3" style="max-width: 540px; height: 200px">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="..." class="card-img" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body" style="width: 540px;">
                    <h5 class="card-title">Naam Fiets</h5>
                    <p class="card-text">Prijs</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <button type="button" class="btn btn-primary" style="margin-top: 20px; margin-left: 200px;">Informatie</button>
                </div>
            </div>
        </div>
    </div>
    <div class="card mb-3" style="max-width: 540px; height: 200px; float: right; margin-top: -215px">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="..." class="card-img" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body" style="width: 540px;">
                    <h5 class="card-title">Naam Fiets</h5>
                    <p class="card-text">Prijs</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <button type="button" class="btn btn-primary" style="margin-top: 20px; margin-left: 200px;">Informatie</button>
                </div>
            </div>
        </div>
    </div>

</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>