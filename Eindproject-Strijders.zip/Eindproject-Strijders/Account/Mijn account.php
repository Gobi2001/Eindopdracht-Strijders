<?php
$servername = "localhost";
$username = "gsugunakumar_2001" ;
$password = "Gobihan2001";
$dbname = "gsugunakumar_Eindopdracht-Strijders";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM Gegevens";
$result = $conn->query($sql);
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FietsenWinkel Strijders</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>


<body>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="../Home/Homepage.php">Fietsenwinkel</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../Home/Homepage.php">Home
                        <span class="sr-only">(current)</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Inloggen/login.php">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Registreren/registreren.php">Registreren</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Winkelwagen/Winkelwagen.php">Winkelwagen</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="../Account/Mijn%20account.php">Profiel</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main>

<div class="media">
    <img src="" class="mr-3"  style= "margin-left: 80px; margin-top: 30px" alt="...">
    <div class="media-body">
    </div>
</div>
<button type="button" class="btn btn-primary" style= "margin-left: 25px; margin-top: 50px">VERANDER FOTO</button>
<form>

    <div class="form-group row">
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: 25px; margin-top: 50px">E-mail</label>
        <div class="col">
            <input type="text" class="form-control" placeholder="email@example.com" style= "margin-top: 50px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 100px">Voornaam</label>
        <div class="col">
            <input type="text" class="form-control"  style= "margin-top: 100px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 150px">Tussenvoegsels</label>
        <div class="col">
            <input type="text" class="form-control"  style= "margin-top: 150px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 200px">Achternaam</label>
        <div class="col">
            <input type="text" class="form-control"  style= "margin-top: 200px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 250px">Geboortedatum</label>
        <div class="col">
            <input type="text" class="form-control" placeholder="yyyy-mm-dd" style= "margin-top: 250px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 300px">Postcode</label>
        <div class="col">
            <input type="text" class="form-control" placeholder="0000 AB" style= "margin-top: 300px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1322px; margin-top: 350px">Straat</label>
        <div class="col">
            <input type="text" class="form-control"  style= "margin-top: 350px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 400px">Huisnummer</label>
        <div class="col">
            <input type="text" class="form-control"  style= "margin-top: 400px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 450px">Plaats</label>
        <div class="col">
            <input type="text" class="form-control"  style= "margin-top: 450px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 500px">Tel.</label>
        <div class="col">
            <input type="text" class="form-control"  style= "margin-top: 500px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 550px">Gebruikersnaam</label>
        <div class="col">
            <input type="text" class="form-control"  style= "margin-top: 550px">
        </div>
        <label for="inputPassword" class="col-sm-2 col-form-label " style= "margin-left: -1320px; margin-top: 600px">Wachtwoord</label>
        <div class="col">
            <input type="text" class="form-control"  style= "margin-top: 600px">
        </div>
    </div>
    <div class="row">
        <legend class="col-form-label col-sm-2 pt-0" style="margin-left: 20px">Geslacht</legend>
        <div class="col-sm-10">
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked style="margin-left: 230px; margin-top: -20px;">
                <label class="form-check-label" for="gridRadios1" style="margin-left: 230px; ">
                    Man
                </label>
                <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2" checked style="margin-left: 200px; margin-top: -20px;">
                <label class="form-check-label" for="gridRadios2" style="margin-left: 200px;">
                    Vrouw
                </label>
            </div>
            <button type="button" class="btn btn-primary" style="margin-left: 30px; margin-top: 20px;">Wijzig geegvens</button>
            <a href="../Bestelling/Mijn%20bestellingen.php"><button type="button" class="btn btn-primary"  style= "margin-left: 25px; margin-top: 50px">Mijn besteliing</button></a>
</form>

</main>
<footer class="py-5 bg-dark">
    <div class="container" style="text-align: center">
        <br>
        <h5 class="text-white"> Nieuwsbrief</h5>
        <h5 class="text-white">Blijf op de hoogte</h5>
        <p class="text-white">Bevestig uw e-mail om op de hoogte te blijven<br>
            van de niewste fietsen en meer!</p>
        <form class="footer__subscription-form" target="blank" action="#" method="post">
            <div class="input-field ">
                <input type='text'  name='inputEmail' placeholder='Email Address' required/>
            </div>
            <br>
            <input type="hidden" name="iehack" value="☠">
            <button type="submit" class="btn btn-primary">Verstuur</button>
        </form>
        <br>
        <p class="m-0 text-center text-white">Copyright &copy; Eindopdracht Strijders 2019</p>
    </div>
</footer>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>