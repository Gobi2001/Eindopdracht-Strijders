<?php

$input_email = filter_input(INPUT_POST, 'Email');
if(!empty($input_email)) {
    $servername = "localhost";
    $username = "gsugunakumar_2001" ;
    $password = "Gobihan2001";
    $dbname = "gsugunakumar_Eindopdracht-Strijders";


// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    if (mysqli_connect_error())
    {
        die('Connect error (' . mysqli_connect_errno() .')'
        . mysqli_connect_error());
    }
    else {
        $sql = "INSERT INTO nieuwsbrief(id, Email)
                VALUES (NULL , $input_email)";
        if($conn->query($sql)){
            echo "Bedankt voor het aanmelden voor de nieuwsbrief";
        }
        else{
            echo "Error: " . $sql . "<br>" .$conn->error;
        }
        $conn->close();
    }
}
?>