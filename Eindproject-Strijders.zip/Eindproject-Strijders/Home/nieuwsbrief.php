<?php

$input_email = filter_input(INPUT_POST, 'Email');
if(!empty($input_email)) {
    $servername = "localhost:3306";
    $username = "root";
    $password = "Graafschap1562";
    $database = rluesink_Php;


// Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    if (mysqli_connect_error())
    {
        die('Connect error (' . mysqli_connect_errno() .')'
        . mysqli_connect_error());
    }
    else {
        $sql = "INSERT INTO nieuwsbrief(id, Email)
                VALUES (NULL , $input_email)";
        if($conn->query($sql)){
            echo "Bedankt voor het aanmelden voor de nieuwsbrief";
        }
        else{
            echo "Error: " . $sql . "<br>" .$conn->error;
        }
        $conn->close();
    }
}
?>