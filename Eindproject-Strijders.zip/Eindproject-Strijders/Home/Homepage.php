<?php
$link = mysqli_connect("localhost" , "gsugunakumar_2001", "Gobihan2001");
mysqli_select_db($link,"gsugunakumar_Eindopdracht-Strijders");
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>FietsenWinkel Strijders</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">

</head>

<body>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="../Home/Homepage.php">Fietsenwinkel</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="../Home/Homepage.php">Home
                        <span class="sr-only">(current)</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Inloggen/login.php">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Registreren/registreren.php">Registreren</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Winkelwagen/Winkelwagen.php">Winkelwagen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Account/Mijn%20account.php">Profiel</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main>
<!-- Page Content -->
<div class="container bg-light col-lg-9">
    <div class="row">
        <div class="rowimage col-lg-3">
            <h1 class="my-4">Case Chain Gang</h1>
            <div class="list-group">
                <a href="../Categorie/Categoriepagina.php" class="list-group-item text-dark">Mannen Fietsen</a>
                <a href="../Categorie/Categoriepagina.php" class="list-group-item text-dark">Vrouwen Fietsen</a>
                <a href="../Categorie/Categoriepagina.php" class="list-group-item text-dark">Kinder Fietsen</a>
            </div>

        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

            <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner" role="listbox">
                    <div class="carousel-item active">
                        <img class="d-block img-fluid" src="Picture/RFiets.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block img-fluid" src="Picture/EFiets.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block img-fluid" src="Picture/EM.jpg" alt="Third slide">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>

            <div class="row col-lg-12">
                <h1 class="row col-lg-12">Laatst Toegevoegde Fietsen</h1>
                <div class="row bg-light">
                    <?php
                    $res = mysqli_query($link, "select * from aanbiedingen");
                    while ($row = mysqli_fetch_array($res)) {
                        ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card h-100">

                                <a href="#">
                                    <?php
                                    echo "<img class=\"card-img-top\" src=\"{$row['plaatje']}\" >";
                                    ?>

                                <div class="card-body">
                                    <h4 class="card-title">
                                        <a href="#"><?php echo $row["naam"]?></a>
                                    </h4>
                                    <h5>€ <?php echo $row["prijs"] ?></h5>
                                    <p class="card-text"><?php echo $row["beschrijving"] ?></p>
                                    <a href="#" class="small btn btn-success col-lg-12">Bekijk de fiets!</a>
                                </div>
                                <div class="card-footer">
                                    <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                    <h1 class="row col-lg-12">Speciale Aanbiedingen</h1>
                    <?php
                    $res = mysqli_query($link, "select * from speciale_aanbiedingen");
                    while ($row = mysqli_fetch_array($res)) {
                        ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card h-100">
                                <a href="#">
                                    <?php
                                    echo "<img class=\"card-img-top\" src=\"{$row['plaatje']}\" >";
                                    ?>
                                </a>
                                <div class="card-body">
                                    <h4 class="card-title">
                                        <a href="#"><?php echo $row["naam"]?></a>
                                    </h4>
                                    <h5 style="color: red"> <strike>€ <?php echo $row["oude_prijs"] ?> </strike></h5>
                                    <h5>€ <?php echo $row["nu_prijs"] ?></h5><br>
                                    <a href="#" class="small btn btn-success col-lg-12">Bekijk de fiets!</a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>

                    <div class="card card-outline-secondary my-4">
                        <div class="card-header">
                            Product Reviews
                        </div>
                        <div class="card-body">
                            <p>De kleuren van de fiets zijn iets anders dan op de foto. Het blauw is iets lichter en iets zachter, maar naar mening maakt dit de fiets juist mooier. Hij fiets super lekker heeft alleen geen stuurslot, maar voor de rest ben ik er heel erg blij mee!! </p>
                            <small class="text-muted">Posted by HazelBelle on 17/5/19</small>
                            <hr>
                            <p>Een heel goede fiets tegen een zeer redelijke prijs. Er waren wat moeilijkheden met de bezorging, waardoor hij later was gekomen dan voorgesteld, maar op dit na ben ik er écht tevreden mee.</p>
                            <small class="text-muted">Posted by emcameron on 26/3/19</small>
                            <hr>
                            <p>Een degelijke fiets die licht trapt, goed zelf in elkaar te zetten is en met een duidelijke handleiding. Door de standaard is de fiets goed overal te parkeren. De extra bagagedrager is prettig door de extra vervoersmogelijkheid bijvoorbeeld boodschappenkrat.</p>
                            <small class="text-muted">Posted by Markdeeeuwigestudent on 25/8/18</small>
                            <hr>
                            <a class="small btn btn-success text-white">Leave a Review</a>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.col-lg-9 -->
        </div>
        <!-- /.row -->
    </div>
</main>

    <!-- /.container -->
    <!-- Footer -->

            <footer class="py-5 bg-dark">
                <div class="container" style="text-align: center">
                    <br>
                    <h5 class="text-white"> Nieuwsbrief</h5>
                    <h5 class="text-white">Blijf op de hoogte</h5>
                    <p class="text-white">Bevestig uw e-mail om op de hoogte te blijven<br>
                        van de niewste fietsen en meer!</p>
                    <form class="footer__subscription-form" target="blank" action="#" method="post">
                        <div class="input-field ">
                            <input type='text'  name='inputEmail' placeholder='Email Address' required/>
                        </div>
                        <br>
                        <input type="hidden" name="iehack" value="☠">
                        <button type="submit" class="btn btn-primary">Verstuur</button>
                    </form>
                    <br>
                    <p class="m-0 text-center text-white">Copyright &copy; Eindopdracht Strijders 2019</p>
                </div>
            </footer>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>

